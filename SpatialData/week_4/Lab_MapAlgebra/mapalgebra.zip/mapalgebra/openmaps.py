from pcraster import *


buildgMap=readmap("buildg.map")
firestatMap=readmap("firestat.map")
iswaterMap=readmap("iswater.map")
phreaticMap=readmap("phreatic.map")
rainstorMap=readmap("rainstor.map")
roadsMap=readmap("roads.map")
topoMap=readmap("topo.map")
waterMap=readmap("water.map")
dumpMap=readmap("dump.map")
isroadMap=readmap("isroad.map")
loggingMap=readmap("logging.map")
pointsMap=readmap("points.map")
rainyearMap=readmap("rainyear.map")
soilsMap=readmap("soils.map")
treesMap=readmap("trees.map")
wellsMap=readmap("wells.map")
